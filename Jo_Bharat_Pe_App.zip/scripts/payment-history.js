document.addEventListener("DOMContentLoaded", loadHistory);

function loadHistory() {
    let historyList = document.getElementById("history-list");
    let transactions = JSON.parse(localStorage.getItem("transactions")) || [];

    historyList.innerHTML = "";
    transactions.forEach(tx => {
        let row = `<tr>
            <td>${tx.date}</td>
            <td>${tx.type}</td>
            <td>${tx.payee}</td>
            <td>₹${tx.amount}</td>
            <td>${tx.status}</td>
        </tr>`;
        historyList.innerHTML += row;
    });
}

function exportCSV() {
    let transactions = JSON.parse(localStorage.getItem("transactions")) || [];
    let csvContent = "Date,Type,Payee,Amount,Status\n";

    transactions.forEach(tx => {
        let row = `${tx.date},${tx.type},${tx.payee},${tx.amount},${tx.status}\n`;
        csvContent += row;
    });

    let blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    let link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "payment-history.csv";
    link.click();
}

function exportPDF() {
    let transactions = JSON.parse(localStorage.getItem("transactions")) || [];
    let doc = new jsPDF();

    doc.setFontSize(18);
    doc.text("Payment History", 14, 16);

    doc.setFontSize(12);
    let yPosition = 30;

    transactions.forEach(tx => {
        doc.text(`Date: ${tx.date}`, 14, yPosition);
        doc.text(`Type: ${tx.type}`, 14, yPosition + 6);
        doc.text(`Payee: ${tx.payee}`, 14, yPosition + 12);
        doc.text(`Amount: ₹${tx.amount}`, 14, yPosition + 18);
        doc.text(`Status: ${tx.status}`, 14, yPosition + 24);
        yPosition += 30;

        if (yPosition > 270) {
            doc.addPage();
            yPosition = 20;
        }
    });

    doc.save("payment-history.pdf");
}