document.addEventListener("DOMContentLoaded", loadSettings);

function loadSettings() {
    const language = localStorage.getItem("language") || "en-IN";
    const speed = localStorage.getItem("voiceSpeed") || "1";
    const pitch = localStorage.getItem("voicePitch") || "1";

    document.getElementById("language-select").value = language;
    document.getElementById("voice-speed").value = speed;
    document.getElementById("voice-pitch").value = pitch;
    document.getElementById("speed-value").innerText = speed;
    document.getElementById("pitch-value").innerText = pitch;
}

function saveSettings() {
    const language = document.getElementById("language-select").value;
    const speed = document.getElementById("voice-speed").value;
    const pitch = document.getElementById("voice-pitch").value;

    localStorage.setItem("language", language);
    localStorage.setItem("voiceSpeed", speed);
    localStorage.setItem("voicePitch", pitch);

    alert("Settings saved successfully!");
}

document.getElementById("voice-speed").addEventListener("input", function() {
    document.getElementById("speed-value").innerText = this.value;
});

document.getElementById("voice-pitch").addEventListener("input", function() {
    document.getElementById("pitch-value").innerText = this.value;
});