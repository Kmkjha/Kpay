document.getElementById("recharge-form").addEventListener("submit", function(e) {
    e.preventDefault();

    const phoneNumber = document.getElementById("phone-number").value;
    const amount = document.getElementById("amount").value;

    if (phoneNumber && amount) {
        alert(`Recharging ${phoneNumber} with ₹${amount}`);
    } else {
        alert("Please fill in all fields!");
    }
});